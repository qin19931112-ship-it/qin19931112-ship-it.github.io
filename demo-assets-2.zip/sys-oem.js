function initFaviconIcon() {
  const link = document.querySelector('link[rel="icon"]');
  if (!link) return;

  let data = null;
  try {
    const raw = localStorage.getItem('TENANT_LOGO');
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = null;
  }

  link.href = data && data.faviconUrl ? data.faviconUrl : '/favicon.png';
}

initFaviconIcon();
