// Local development defaults; deployment generates its own runtime configuration.
window.RUNTIME_CONFIG = window.RUNTIME_CONFIG || {};
