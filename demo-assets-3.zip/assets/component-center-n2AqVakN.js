import{$ as e,C as t,H as n,K as r,S as i,W as a,bt as o,d as s,dt as c,et as l,g as u,h as d,it as f,k as p,q as m,v as h,w as g,wt as _,y as v,yt as y}from"./vue.runtime.esm-bundler-CLaEwzGq.js";import{Qr as b,Ur as x,Wr as S,Zr as C,ei as w,ir as T,nr as E,qr as D,rr as O}from"./index-BYIJiRl8.js";import"./ui-CywsLt-T.js";var k={search:`ips-components-catalog-search`,category:`ips-components-catalog-category`,details:`ips-components-catalog-details`,preview:`ips-components-preview-open`,input:`ips-components-preview-input`},A={vueFileCount:219,components:[{name:`CustomTag`,category:`状态与反馈`,purpose:`统一业务状态标签`,contract:`label / type / desc`,path:`components/vue3/src/CustomTag.vue`,declarations:`defineProps({
  label: {
    type: String,
    required: true,
  },
  type: {
    type: String as PropType<'info' | 'success' | 'warning' | 'danger' | 'primary'>,
    default: 'info',
  },
  desc: {
    type: String,
    default: '',
    required: false,
  },
  dark: {
    type: Boolean,
    default: true,
    required: false,
  },
  enableMinWidth: {
    type: Boolean,
    default: true,
  },
})`,importFrom:`@nx/ui`,examples:[`core/main/src/modules/message-center/MyMessageListModule.vue`,`core/main/src/modules/message-center/components/MessageDetailDrawer.vue`,`core/main/src/modules/warehouse-master/WarehouseMaster.vue`,`apps/main/src/views/component-center/index.vue`,`apps/main/src/views/goods/inventory-management/detail.vue`]},{name:`BackButton`,category:`布局与导航`,purpose:`返回上级页面`,contract:`text；click`,path:`components/vue3/src/BackButton.vue`,declarations:`defineProps({
  text: {
    type: String,
    default: '返回',
  },
})

defineEmits<{ (e: 'click', event: MouseEvent): void }>()`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/inventory/shared/InventoryOperationCreatePage.vue`,`apps/main/src/views/inventory/shared/InventoryOperationDetailPage.vue`,`apps/main/src/views/inventory/stock-transfer/create.vue`,`apps/main/src/views/repair/orders/create.vue`,`apps/main/src/views/repair/orders/detail.vue`]},{name:`MessageBox`,category:`状态与反馈`,purpose:`全局确认对话框，由 onConfirm 调用`,contract:`onConfirm({ title, message, onOk })`,path:`components/vue3/src/message-box/MessageBox.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/components/AppLogin.vue`,`core/main/src/layout/index.vue`,`core/main/src/layout/normal.vue`]},{name:`OfficePreview`,category:`上传与预览`,purpose:`Office 文档预览`,contract:`依赖文档资源及预览插件`,path:`components/vue3/src/office-previewer/OfficePreview.vue`,declarations:`defineProps({
  url: {
    type: String,
    default: '',
  },
})`,importFrom:`@nx/ui`,examples:[`components/vue3/src/office-previewer/OfficePreview.vue`]},{name:`SmsButton`,category:`表单与选择`,purpose:`短信发送倒计时`,contract:`依赖验证码发送接口`,path:`components/vue3/src/sms-button/SmsButton.vue`,declarations:`defineEmits(['send-sms'])

defineProps({
  disabled: {
    type: Boolean,
    default: false,
  },
  defaultLabel: {
    type: String,
    default: '发送验证码',
  },
  interval: {
    type: Number,
    default: 60,
  },
  isPrimary: {
    type: Boolean,
    default: false,
  },
  inline: {
    type: Boolean,
    default: false,
  },
})`,importFrom:`@nx/ui`,examples:[`core/main/src/components/AppLogin.vue`,`core/main/src/components/member-identity/MemberIdentityVerifyModal.vue`]},{name:`Steps`,category:`流程与业务`,purpose:`步骤进度与步骤切换`,contract:`steps / activeKey；confirm`,path:`components/vue3/src/steps/Steps.vue`,declarations:`defineEmits(['confirm'])

defineProps({
  steps: {
    type: Array as PropType<IStepItem[]>,
    default: () => [],
    required: true,
  },
  activeKey: {
    type: String,
    default: '',
  },
  maxWidth: {
    type: Number,
    default: 0,
  },
  maxItemWidth: {
    type: Number,
    default: 0,
  },
})`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/component-center/index.vue`,`apps/main/src/views/inventory/stock-transfer/create.vue`,`apps/main/src/views/repair/orders/detail.vue`,`apps/main/src/views/supply-chain/shared/SupplyCreate.vue`]},{name:`AreaSelect`,category:`表单与选择`,purpose:`行政区域选择`,contract:`依赖区域选项数据`,path:`components/vue3/src/AreaSelect.vue`,declarations:`defineEmits<{
  'key-enter': [];
  change: [value: string[]];
}>()

defineProps({
  initialCodes: {
    type: Array as PropType<string[]>,
    required: true,
  },
  enableTown: {
    type: Boolean,
    default: true,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  provPlaceholder: {
    type: String,
    default: '请选择',
  },
  cityPlaceholder: {
    type: String,
    default: '请选择',
  },
  townPlaceholder: {
    type: String,
    default: '请选择',
  },
})`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/subject-store/store-management/detail.vue`,`apps/main/src/views/subject-store/store-management/index.vue`]},{name:`LeafCategorySelect`,category:`表单与选择`,purpose:`只选择叶子类目`,contract:`modelValue / options；update:modelValue`,path:`components/vue3/src/LeafCategorySelect.vue`,declarations:`defaults: {
  modelValue: undefined,
  options: () => [],
  placeholder: '请选择适用类目',
  multiple: true,
  allowClear: true,
  allowSearch: undefined,
  disabled: false,
  loading: false,
  tagText: '叶子',
  labelMode: 'name',
}

defineProps<{
  modelValue?: LeafCategoryModelValue;
  options?: SelectOption[];
  placeholder?: string;
  multiple?: boolean;
  allowClear?: boolean;
  allowSearch?: boolean | { retainInputValue?: boolean };
  disabled?: boolean;
  loading?: boolean;
  tagText?: string;
  labelMode?: LeafCategoryLabelMode;
}>()

defineEmits<{
  'update:modelValue': [value: LeafCategoryModelValue | undefined];
  change: [value: LeafCategoryModelValue | undefined];
}>()`,importFrom:`@nx/ui`,examples:[]},{name:`CardImageUpload`,category:`上传与预览`,purpose:`证件卡片图片上传`,contract:`经上传接口；不在展台发送文件`,path:`components/vue3/src/card-image-upload/CardImageUpload.vue`,declarations:`defineEmits<{ 'on-success': [context: any, file: File] }>()

defineProps({
  messageBeforeUpload: {
    type: String,
    default: '',
  },
  action: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    default: '',
  },
  width: {
    type: Number,
    default: 314,
  },
  height: {
    type: Number,
    default: 202,
  },
  readonly: {
    type: Boolean,
    default: false,
  },
  placeholderImage: {
    type: String,
    default: 'none',
  },
  maxFileSize: {
    type: Number,
    default: 5,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  desc: {
    type: String,
    default: '',
  },
  data: {
    type: Object as PropType<Record<string, any>>,
    default: () => ({}),
  },
})`,importFrom:`@nx/ui`,examples:[`core/main/src/components/member-identity/MemberIdentityCompleteDrawer.vue`,`apps/main/src/views/subject-store/store-management/detail.vue`,`apps/main/src/views/subject-store/store-management/index.vue`]},{name:`QrImageUpload`,category:`上传与预览`,purpose:`单图与二维码上传`,contract:`经上传接口；不在展台发送文件`,path:`components/vue3/src/qr-image-upload/QrImageUpload.vue`,declarations:`defaults: {
  modelValue: '',
  fileName: '',
  accept: 'image/*',
  maxFileSize: 5,
  placeholder: '点击上传图片',
  hint: '支持常见图片格式，建议清晰无遮挡',
  description: '',
  previewSize: 80,
  triggerHeight: 180,
  fallbackFileName: '已上传图片',
  alt: 'image',
  disabled: false,
}

defineProps<{
  /** 图片地址（v-model） */
  modelValue?: string;
  /** 上传后的文件名（v-model:fileName，可选） */
  fileName?: string;
  /** 文件类型限制，沿用浏览器 accept 语法 */
  accept?: string;
  /** 单文件大小上限（MB） */
  maxFileSize?: number;
  /** 触发区文案 */
  placeholder?: string;
  /** 触发区下方说明文案（小字） */
  hint?: string;
  /** 触发区上方说明（一行普通段落，可选） */
  description?: string;
  /** 缩略图边长（px） */
  previewSize?: number;
  /** 触发区高度（px） */
  triggerHeight?: number;
  /** 缺省文件名（无 fileName 时显示） */
  fallbackFileName?: string;
  /** 图片 alt 文案 */
  alt?: string;
  /** 是否禁用 */
  disabled?: boolean;
}>()

defineEmits<{
  'update:modelValue': [picUrl: string];
  'update:fileName': [fileName: string];
  success: [result: IPicUploadResult, file: File];
  error: [error: Error];
}>()`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/master-data/components/MasterDataPage.vue`,`apps/main/src/views/master-data/components/ProductImages.vue`,`apps/main/src/views/repair/orders/RepairPhotos.vue`]},{name:`DateRangeWithLongTerm`,category:`表单与选择`,purpose:`日期区间与长期有效`,contract:`见源码起止日期绑定`,path:`components/vue3/src/DateRangeWithLongTerm.vue`,declarations:`defaults: {
  startDate: '',
  endDate: '',
  longTerm: false,
  valueFormat: 'YYYY-MM-DD',
  defaultStartDate: '1950-01-01',
  longTermDate: '2999-12-31',
}

defineProps<{
  startDate?: string;
  endDate?: string;
  longTerm?: boolean;
  valueFormat?: string;
  defaultStartDate?: string;
  longTermDate?: string;
}>()

defineEmits<{
  (e: 'update:startDate', value: string): void;
  (e: 'update:endDate', value: string): void;
  (e: 'update:longTerm', value: boolean): void;
  (e: 'change'): void;
}>()`,importFrom:`@nx/ui`,examples:[`core/main/src/components/member-identity/MemberIdentityCompleteDrawer.vue`,`apps/main/src/views/component-center/index.vue`]},{name:`FileUpload`,category:`上传与预览`,purpose:`通用文件上传及附件列表`,contract:`modelValue；依赖上传接口`,path:`components/vue3/src/FileUpload.vue`,declarations:`defaults: {
  modelValue: '',
  imageAction: '',
  accept: uploadAcceptTypes.image,
  limit: 1,
  maxFileSize: 5,
  maxImageFileSize: 5,
  data: () => ({}),
  disabled: false,
  readonly: false,
  tip: '',
  messageBeforeUpload: '',
  triggerText: '上传文件',
  showFileList: true,
  hideImageLoaderText: false,
  imageGrid: false,
}

defineProps<{
  modelValue?: string | string[];
  action: string;
  /** 图片文件专用上传地址；不传时沿用公共图片上传地址。 */
  imageAction?: string;
  accept?: string;
  limit?: number;
  maxFileSize?: number;
  maxImageFileSize?: number;
  data?: Record<string, any>;
  disabled?: boolean;
  readonly?: boolean;
  tip?: string;
  messageBeforeUpload?: string;
  triggerText?: string;
  /** 是否展示已上传文件列表；头像等自定义展示场景可关闭。 */
  showFileList?: boolean;
  /** 图片加载中只显示居中的小图标，不显示默认加载文案。 */
  hideImageLoaderText?: boolean;
  /** 图片是否以正方形缩略图网格展示，并支持点击预览。 */
  imageGrid?: boolean;
}>()

defineEmits<{
  'update:modelValue': [value: string | string[]];
  'on-success': [response: any, file: File];
  'on-error': [error: Error];
}>()`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/goods/product-management/detail.vue`,`apps/main/src/views/inventory-documents/appraisal-order/review.vue`,`apps/main/src/views/sales-customer/member-center/detail.vue`,`apps/main/src/views/sales-customer/member-center/index.vue`]},{name:`TableRowButtons`,category:`数据展示`,purpose:`表格行操作及更多菜单`,contract:`权限和操作数组由业务传入`,path:`components/vue3/src/table-row-buttons/TableRowButtons.vue`,declarations:`defineProps({
  row: {
    type: Object as PropType<Record<string, any>>,
    default: () => ({}),
  },
  buttons: {
    type: Array as PropType<Array<ITableOperator>>,
    default: () => [],
  },
})

defineEmits(['click'])`,importFrom:`@nx/ui`,examples:[]},{name:`Footer`,category:`布局与导航`,purpose:`页面页脚`,contract:`复用现有样式`,path:`components/vue3/src/Footer.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`apps/main/src/views/repair/orders/create.vue`,`apps/main/src/views/supply-chain/shared/SupplyFrame.vue`,`apps/main/src/views/system/users/UserEditor.vue`,`apps/main/src/views/workflow/Detail.vue`]},{name:`NotSupportBrowser`,category:`状态与反馈`,purpose:`不支持浏览器提示`,contract:`浏览器检测工具配套`,path:`components/vue3/src/not-support-browser/NotSupportBrowser.vue`,declarations:`defineProps({
  error: {
    type: String,
    default: '',
  },
})`,importFrom:`@nx/ui`,examples:[`core/main/src/CommonApp.vue`]},{name:`ContentContainer`,category:`布局与导航`,purpose:`列表与详情内容容器`,contract:`title；tabs / search-buttons / left-buttons / footer`,path:`core/main/src/layout/content-container/index.vue`,declarations:`defineProps({
  /** content 区域的标题 */
  title: {
    type: String,
    required: false,
    default: '',
  },
  /** 标题下方说明文案 */
  titleDescription: {
    type: String,
    required: false,
    default: '',
  },
  headerStyle: {
    type: Object,
    required: false,
    default: () => ({}),
  },
})`,importFrom:`@nx/ui`,examples:[`core/main/src/modules/message-center/MyMessageListModule.vue`,`apps/main/src/views/component-center/index.vue`,`apps/main/src/views/goods/inventory-management/index.vue`,`apps/main/src/views/goods/price-center/index.vue`,`apps/main/src/views/goods/product-management/index.vue`]},{name:`SearchContainer`,category:`表单与选择`,purpose:`响应式搜索区与展开收起`,contract:`默认插槽 / buttons`,path:`core/main/src/layout/search-container/index.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/modules/message-center/MyMessageListModule.vue`,`apps/main/src/views/component-center/index.vue`,`apps/main/src/views/goods/inventory-management/index.vue`,`apps/main/src/views/goods/price-center/index.vue`,`apps/main/src/views/goods/product-management/index.vue`]},{name:`SearchCol`,category:`表单与选择`,purpose:`搜索字段列`,contract:`放入 SearchContainer`,path:`core/main/src/layout/search-container/SearchCol.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/modules/message-center/MyMessageListModule.vue`,`apps/main/src/views/component-center/index.vue`,`apps/main/src/views/goods/inventory-management/index.vue`,`apps/main/src/views/goods/price-center/index.vue`,`apps/main/src/views/goods/product-management/index.vue`]},{name:`NormalTable`,category:`数据展示`,purpose:`表格、分页、列显隐及密度`,contract:`columns / data / total / page；pageChange；列配置当前为全局状态，多表同屏用 Arco Table`,path:`core/main/src/components/NormalTable.vue`,declarations:`defineEmits(['pageChange'])

defineProps({
  loading: {
    type: Boolean,
    default: false,
  },
  /**
   * 自定义columns数组
   */
  columns: {
    type: Array as PropType<IColumn[]>,
    default: () => [],
  },
  data: {
    type: Array as PropType<any[]>,
    default: () => [],
  },
  total: {
    type: Number,
    default: 0,
  },
  /**
   * 是否展示分页配置
   */
  showPagination: {
    type: Boolean,
    default: true,
  },
  page: {
    type: Number,
    default: 1,
  },
  pageSize: {
    type: Number,
    default: undefined,
  },
  pageSizeOptions: {
    type: Array as PropType<number[]>,
    default: undefined,
  },
})`,importFrom:`@nx/ui`,examples:[`core/main/src/modules/message-center/MyMessageListModule.vue`,`apps/main/src/views/component-center/index.vue`,`apps/main/src/views/goods/inventory-management/index.vue`,`apps/main/src/views/goods/price-center/index.vue`,`apps/main/src/views/goods/product-management/index.vue`]},{name:`TableExtraEffect`,category:`数据展示`,purpose:`表格列配置与密度工具`,contract:`配合 NormalTable`,path:`core/main/src/components/TableExtraEffect.vue`,declarations:`defineEmits(['search'])`,importFrom:`@nx/ui`,examples:[`core/main/src/modules/message-center/MyMessageListModule.vue`,`apps/main/src/views/goods/inventory-management/index.vue`,`apps/main/src/views/goods/price-center/index.vue`,`apps/main/src/views/goods/product-management/index.vue`,`apps/main/src/views/goods/storage-location-management/index.vue`]},{name:`StatisticTabs`,category:`数据展示`,purpose:`带数量的状态筛选`,contract:`items / activeKey；select`,path:`core/main/src/components/StatisticTabs.vue`,declarations:`defaults: { ariaLabel: '统计筛选' }

defineProps<{
  /** tabs 数据。 */
  items: IStatisticTabsItem[];
  /** 当前激活项 key。 */
  activeKey: string;
  /** 无障碍标签。 */
  ariaLabel?: string;
}>()

defineEmits<{
  /** 选择 tabs 项。 */
  select: [item: IStatisticTabsItem];
}>()`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/component-center/index.vue`,`apps/main/src/views/goods/inventory-management/index.vue`,`apps/main/src/views/goods/price-center/index.vue`,`apps/main/src/views/goods/product-management/index.vue`,`apps/main/src/views/inventory-documents/appraisal-order/index.vue`]},{name:`CommonLayout`,category:`布局与导航`,purpose:`导航、侧栏、多页签后台布局`,contract:`依赖路由 / store / 宿主上下文`,path:`core/main/src/layout/index.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`apps/main/src/layout/default.vue`]},{name:`NormalLayout`,category:`布局与导航`,purpose:`无侧栏布局`,contract:`依赖宿主上下文`,path:`core/main/src/layout/normal.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`apps/main/src/layout/normal.vue`]},{name:`OnlyNavLayout`,category:`布局与导航`,purpose:`仅顶部导航布局`,contract:`依赖宿主上下文`,path:`core/main/src/layout/onlyNav.vue`,declarations:`defineProps({
  noTopMenus: {
    type: Boolean,
    default: false,
  },
})`,importFrom:`@nx/ui`,examples:[`apps/main/src/layout/simple.vue`]},{name:`MemberIdentityCompleteDrawer`,category:`流程与业务`,purpose:`会员身份资料完善抽屉`,contract:`会员专用，不直接复用到租户主数据`,path:`core/main/src/components/member-identity/MemberIdentityCompleteDrawer.vue`,declarations:`defaults: { member: null }

defineProps<{
  /** 抽屉显隐。 */
  visible: boolean;
  /** 当前会员 ID。 */
  memberId: number;
  /** 已加载的会员详情；列表入口不传时组件自行查询。 */
  member?: IMemberDetail | null;
}>()

defineEmits<{
  /** 更新抽屉显隐。 */
  'update:visible': [value: boolean];
  /** 证件保存成功。 */
  success: [];
}>()`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/sales-customer/member-center/detail.vue`,`apps/main/src/views/sales-customer/member-center/index.vue`]},{name:`MemberIdentityVerifyModal`,category:`流程与业务`,purpose:`会员实名认证对话框`,contract:`依赖会员接口`,path:`core/main/src/components/member-identity/MemberIdentityVerifyModal.vue`,declarations:`defineProps<{
  /** 弹框显隐。 */
  visible: boolean;
  /** 当前会员 ID。 */
  memberId: number;
  /** 会员原始姓名；列表入口可直接传入。 */
  memberName?: string;
  /** 会员原始身份证号；详情入口可直接传入。 */
  idCardNo?: string;
  /** 会员原始手机号；列表入口可直接传入。 */
  phone?: string;
  /** 已加载的会员详情；列表入口不传时组件自行查询。 */
  member?: IMemberDetail | null;
}>()

defineEmits<{
  /** 更新弹框显隐。 */
  'update:visible': [value: boolean];
  /** 实名认证成功。 */
  success: [];
}>()`,importFrom:`@nx/ui`,examples:[`apps/main/src/views/sales-customer/member-center/detail.vue`,`apps/main/src/views/sales-customer/member-center/index.vue`]},{name:`IcpFooter`,category:`布局与导航`,purpose:`备案信息页脚`,contract:`由部署配置提供内容`,path:`core/main/src/components/IcpFooter.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/components/AppLogin.vue`,`core/main/src/components/SsoCallback.vue`,`core/main/src/components/SsoFallback.vue`,`core/main/src/components/SsoLoginEntry.vue`]},{name:`SvgIcon`,category:`基础控件`,purpose:`统一 Iconify 图标入口`,contract:`icon / class`,path:`packages/commons-demo/index.ts`,declarations:``,importFrom:`@nx/ui`,examples:[`components/vue3/src/BackButton.vue`,`components/vue3/src/CustomTag.vue`,`components/vue3/src/message-box/MessageBox.vue`,`components/vue3/src/not-support-browser/NotSupportBrowser.vue`,`components/vue3/src/qr-image-upload/QrImageUpload.vue`]},{name:`Page404`,category:`状态与反馈`,purpose:`不存在页面`,contract:`路由兜底`,path:`packages/commons-demo/Page404.vue`,declarations:``,importFrom:`@nx/ui`,examples:[]},{name:`AppSwitcher`,category:`平台导航`,purpose:`九宫格应用启动器：三列图标、当前应用、键盘及异步加载`,contract:`currentCode / loadApps / openApp`,path:`packages/commons-demo/AppSwitcher.vue`,declarations:`defaults: {
  currentCode: '',
  loadApps: () => Promise.resolve([]),
  openApp: () => Promise.resolve(false),
}

defineProps<{
  currentCode?: string;
  loadApps?: () => Promise<ILauncherApp[]>;
  openApp?: (app: ILauncherApp) => Promise<boolean>;
}>()`,importFrom:`@nx/ui`,examples:[`core/main/src/layout/nav.vue`]},{name:`TenantSwitcher`,category:`布局与导航`,purpose:`租户选择与切换`,contract:`依赖 provideCommonsContext`,path:`packages/commons-demo/TenantSwitcher.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/layout/nav.vue`]},{name:`ThemeToggle`,category:`基础控件`,purpose:`切换浅色和深色`,contract:`依赖宿主 useDark 主题同步`,path:`packages/commons-demo/ThemeToggle.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/layout/nav.vue`]},{name:`FullscreenToggle`,category:`基础控件`,purpose:`浏览器全屏切换`,contract:`依赖浏览器全屏能力`,path:`packages/commons-demo/FullscreenToggle.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/layout/nav.vue`]},{name:`UserMenu`,category:`布局与导航`,purpose:`头像、个人信息、修改手机号、修改密码及退出入口`,contract:`依赖 provideCommonsContext；context 插槽可嵌入业务空间切换，宿主提供账号弹窗与退出动作`,path:`packages/commons-demo/UserMenu.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`core/main/src/layout/nav.vue`]},{name:`PersonalCenterPage`,category:`流程与业务`,purpose:`个人头像、基本信息、部门岗位和角色；不展示租户身份`,contract:`依赖宿主资料查询、头像上传和账号安全操作`,path:`packages/commons-demo/PersonalCenterPage.vue`,declarations:``,importFrom:`@nx/ui`,examples:[`apps/main/src/views/personal-center/index.vue`]}],remaining:[{path:`components/vue3/src/404.vue`,role:`内部组件／历史实现`},{path:`components/vue3/src/SvgIcon.vue`,role:`内部组件／历史实现`},{path:`components/vue3/src/not-support-browser/cards.vue`,role:`内部组件／历史实现`},{path:`core/main/src/CommonApp.vue`,role:`内部组件／历史实现`},{path:`core/main/src/components/AppLogin.vue`,role:`内部组件／历史实现`},{path:`core/main/src/components/SsoCallback.vue`,role:`内部组件／历史实现`},{path:`core/main/src/components/SsoFallback.vue`,role:`内部组件／历史实现`},{path:`core/main/src/components/SsoLoginEntry.vue`,role:`内部组件／历史实现`},{path:`core/main/src/components/SsoLogout.vue`,role:`内部组件／历史实现`},{path:`core/main/src/components/SsoSilentCallback.vue`,role:`内部组件／历史实现`},{path:`core/main/src/layout/ShopSwitcher.vue`,role:`内部组件／历史实现`},{path:`core/main/src/layout/breadcrumbItems.vue`,role:`内部组件／历史实现`},{path:`core/main/src/layout/nav.vue`,role:`内部组件／历史实现`},{path:`core/main/src/layout/sidebar.vue`,role:`内部组件／历史实现`},{path:`core/main/src/layout/sidebarItems.vue`,role:`内部组件／历史实现`},{path:`core/main/src/layout/tabs.vue`,role:`内部组件／历史实现`},{path:`core/main/src/modules/message-center/MyMessageListModule.vue`,role:`内部组件／历史实现`},{path:`core/main/src/modules/message-center/components/MessageBell.vue`,role:`内部组件／历史实现`},{path:`core/main/src/modules/message-center/components/MessageDetailDrawer.vue`,role:`内部组件／历史实现`},{path:`core/main/src/modules/warehouse-master/WarehouseMaster.vue`,role:`内部组件／历史实现`},{path:`apps/main/src/App.vue`,role:`内部组件／历史实现`},{path:`apps/main/src/components/AccountSecurityModal.vue`,role:`内部组件／历史实现`},{path:`apps/main/src/layout/default.vue`,role:`内部组件／历史实现`},{path:`apps/main/src/layout/normal.vue`,role:`内部组件／历史实现`},{path:`apps/main/src/layout/simple.vue`,role:`内部组件／历史实现`},{path:`apps/main/src/views/catalog/CatalogPlaceholder.vue`,role:`业务页面`},{path:`apps/main/src/views/component-center/index.vue`,role:`业务页面`},{path:`apps/main/src/views/contract/contract-center/index.vue`,role:`业务页面`},{path:`apps/main/src/views/contract/contract-template/index.vue`,role:`业务页面`},{path:`apps/main/src/views/contract/invoice-application/index.vue`,role:`业务页面`},{path:`apps/main/src/views/errors/forbidden/index.vue`,role:`业务页面`},{path:`apps/main/src/views/fund-center/financial-workbench/index.vue`,role:`业务页面`},{path:`apps/main/src/views/fund-center/settlement-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/goods/inventory-management/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/goods/inventory-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/goods/price-center/index.vue`,role:`业务页面`},{path:`apps/main/src/views/goods/product-management/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/goods/product-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/goods/storage-location-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/goods/warehouse-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/home/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/counts/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/documents/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/inbound/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/ledger/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/operations/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/outbound/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-operations/ProductDocumentDetail.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-operations/ProductDocumentDraft.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-operations/ProductDocumentsPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-operations/ProductLedgerPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-operations/ProductShipmentDraft.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-operations/ProductShipmentHandover.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-stock/BatchDetails.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-stock/UnitDetails.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-stock/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/product-stock/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/receipts/Create.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/receipts/ReceiptOperations.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/receipts/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryDocumentsPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryDraftDialog.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryDraftFrame.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryLedgerPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryObjectTabs.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryOperationCreatePage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryOperationDetailPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryOperationDraft.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryStockPicker.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/InventoryTransferDraft.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/MaterialReturnSource.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/SpareCountsPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/SpareLedgerPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/StockDocumentPanel.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/shared/StockDocumentsPage.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/spare-stock/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/spare-stock/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/stock-transfer/create.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory/transfer/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/appraisal-order/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/appraisal-order/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/appraisal-order/review.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/handover-order/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/handover-order/index.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/inventory-check-order/create.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/inventory-check-order/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/inventory-documents/inventory-check-order/index.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/attributes/index.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/brands/index.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/categories/index.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/components/AttributeValueInput.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/components/BrandLogo.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/components/MasterDataPage.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/components/ProductImages.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/models/index.vue`,role:`业务页面`},{path:`apps/main/src/views/master-data/spare-items/index.vue`,role:`业务页面`},{path:`apps/main/src/views/message-center/my-message/index.vue`,role:`业务页面`},{path:`apps/main/src/views/ningxiaoshou/operating-subjects/index.vue`,role:`业务页面`},{path:`apps/main/src/views/ningxiaoshou/planned/index.vue`,role:`业务页面`},{path:`apps/main/src/views/overview/BusinessFlow.vue`,role:`业务页面`},{path:`apps/main/src/views/overview/BusinessMaps.vue`,role:`业务页面`},{path:`apps/main/src/views/overview/ProductOverview.vue`,role:`业务页面`},{path:`apps/main/src/views/overview/SwimlaneCanvas.vue`,role:`业务页面`},{path:`apps/main/src/views/overview/SystemArchitecture.vue`,role:`业务页面`},{path:`apps/main/src/views/overview/index.vue`,role:`业务页面`},{path:`apps/main/src/views/personal-center/index.vue`,role:`业务页面`},{path:`apps/main/src/views/recycle/goods-receiving/index.vue`,role:`业务页面`},{path:`apps/main/src/views/recycle/goods-receiving-return/index.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/commissions/Create.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/commissions/Detail.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/commissions/index.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/Create.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/Detail.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/Putaway.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/ReceiptCreate.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/ReceiptDetail.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/ReceiptSource.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/ShipmentRecords.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/Units.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/intake/index.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/materials/index.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/RepairActionForm.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/RepairMaterialsPanel.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/RepairPhotos.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/RepairPlanMaterials.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/RepairQualityForm.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/RepairQualityHistory.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/create.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/repair/orders/index.vue`,role:`业务页面`},{path:`apps/main/src/views/sales-customer/member-center/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/sales-customer/member-center/index.vue`,role:`业务页面`},{path:`apps/main/src/views/sales-customer/sales-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/sales-customer/sales-return/index.vue`,role:`业务页面`},{path:`apps/main/src/views/sales-customer/sellable-product/index.vue`,role:`业务页面`},{path:`apps/main/src/views/subject-store/employee-management/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/subject-store/employee-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/subject-store/organization-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/subject-store/store-management/detail.vue`,role:`业务页面`},{path:`apps/main/src/views/subject-store/store-management/index.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/orders/ApprovalCreate.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/orders/ApprovalDetail.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/orders/Clearance.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/orders/ProcurementSource.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/orders/Receiving.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/orders/index.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/requests/index.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/shared/SupplyCreate.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/shared/SupplyDetail.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/shared/SupplyFrame.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/shared/SupplyList.vue`,role:`业务页面`},{path:`apps/main/src/views/supply-chain/suppliers/index.vue`,role:`业务页面`},{path:`apps/main/src/views/system/departments/DepartmentFormDrawer.vue`,role:`业务页面`},{path:`apps/main/src/views/system/departments/DepartmentSidebar.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/MenuAuthTree.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RoleEditor.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RoleFormDrawer.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RoleGroupDialog.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RoleMembers.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RoleNameDialog.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RolePermissionPanel.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RolePermissionsDrawer.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/RoleTree.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/UserAddModal.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/form/MenuAuth.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/form/RoleForm.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/form/RoleUsers.vue`,role:`业务页面`},{path:`apps/main/src/views/system/roles/index.vue`,role:`业务页面`},{path:`apps/main/src/views/system/users/RoleAuthTree.vue`,role:`业务页面`},{path:`apps/main/src/views/system/users/UserDetailDrawer.vue`,role:`业务页面`},{path:`apps/main/src/views/system/users/UserEditor.vue`,role:`业务页面`},{path:`apps/main/src/views/system/users/UserForm.vue`,role:`业务页面`},{path:`apps/main/src/views/system/users/UserRolesModal.vue`,role:`业务页面`},{path:`apps/main/src/views/system/users/index.vue`,role:`业务页面`},{path:`apps/main/src/views/warehouse/areas/index.vue`,role:`业务页面`},{path:`apps/main/src/views/warehouse/bins/index.vue`,role:`业务页面`},{path:`apps/main/src/views/warehouse/master/index.vue`,role:`业务页面`},{path:`apps/main/src/views/workbench/BusinessTasks.vue`,role:`业务页面`},{path:`apps/main/src/views/workbench/QuickEntries.vue`,role:`业务页面`},{path:`apps/main/src/views/workbench/index.vue`,role:`业务页面`},{path:`apps/main/src/views/workbench/todo/index.vue`,role:`业务页面`},{path:`apps/main/src/views/workflow/DemoAccountSwitch.vue`,role:`业务页面`},{path:`apps/main/src/views/workflow/Detail.vue`,role:`业务页面`},{path:`apps/main/src/views/workflow/WorkflowTasks.vue`,role:`业务页面`},{path:`apps/main/src/views/workflow/settings/index.vue`,role:`业务页面`}]},j=A;function M(e,t=`全部`){let n=e.trim().toLowerCase();return A.components.filter(e=>(t===`全部`||e.category===t)&&`${e.name} ${e.purpose} ${e.path} ${e.category}`.toLowerCase().includes(n))}p(),f(),o();var N={class:`space-y-5 text-[var(--color-text-1)]`},ee={class:`flex flex-wrap items-start justify-between gap-4 rounded-lg bg-[var(--color-bg-2)] p-6`},te={class:`flex gap-7 text-right`},ne={class:`text-2xl`},re={class:`text-2xl`},ie={class:`grid grid-cols-1 gap-5 xl:grid-cols-2`},ae={class:`mt-6 flex flex-wrap gap-3`},oe={class:`overflow-auto rounded bg-[var(--color-fill-2)] p-4 text-xs`},se={class:`max-h-72 overflow-auto rounded bg-[var(--color-fill-2)] p-4 text-xs`},ce={class:`break-all text-xs`},P={class:`space-y-3 pl-4 text-xs`},F={key:0},I=g({name:`ComponentCenter`,__name:`index`,setup(o){let f=c(``),p=c(`全部`),g=[`全部`,...new Set(j.components.map(e=>e.category))],A=d(()=>M(f.value,p.value)),I=c(null),L=c(!1),R=c(``),z=c(!0),B=c(``),V=c(``),H=c(!1),U=c(`all`),W=c(`start`),G=[{key:`all`,label:`全部`,count:12},{key:`active`,label:`启用`,count:10},{key:`off`,label:`停用`,count:2}],le=[{key:`start`,title:`填写信息`},{key:`done`,title:`完成`}],ue=[{title:`源码路径`,dataIndex:`path`,width:560},{title:`归属`,dataIndex:`role`,width:180}],de=[{title:`组件`,dataIndex:`name`,slotName:`name`,width:220},{title:`分类`,slotName:`category`,width:135},{title:`用途`,dataIndex:`purpose`,width:260},{title:`操作`,slotName:`actions`,width:140}];function fe(){b({title:`确认示例`,message:`此操作仅演示确认弹框，不修改业务数据。`})}return(o,c)=>{let d=r(`a-input`),b=r(`a-select`),M=r(`a-button`),K=r(`a-tab-pane`),pe=r(`a-space`),q=r(`a-form-item`),J=r(`a-form`),me=r(`a-alert`),he=r(`a-empty`),ge=r(`a-table`),Y=r(`a-step`),X=r(`a-steps`),_e=r(`a-divider`),ve=r(`a-tabs`),Z=r(`a-descriptions-item`),ye=r(`a-descriptions`),Q=r(`a-drawer`),be=r(`a-switch`),$=m(`trim-blur`);return n(),v(`div`,N,[u(`div`,ee,[c[17]||=u(`div`,null,[u(`p`,{class:`mb-2 text-xs font-semibold tracking-widest text-[rgb(var(--primary-6))]`},` NING · UI `),u(`h1`,{class:`m-0 text-2xl font-semibold`},` 前端组件中心 `),u(`p`,{class:`mb-0 mt-3 text-sm text-[var(--color-text-3)]`},` 后续页面从这里选组件，共用同一套布局、表格、表单和状态表达。 `)],-1),u(`div`,te,[u(`div`,null,[u(`strong`,ne,_(y(j).components.length),1),c[15]||=u(`p`,{class:`m-0 text-xs text-[var(--color-text-3)]`},` 统一组件入口 `,-1)]),u(`div`,null,[u(`strong`,re,_(y(j).vueFileCount),1),c[16]||=u(`p`,{class:`m-0 text-xs text-[var(--color-text-3)]`},` 已扫描 Vue 文件 `,-1)])])]),t(ve,{"default-active-key":`catalog`},{default:e(()=>[t(K,{key:`catalog`,title:`组件目录`},{default:e(()=>[t(y(T),{title:`组件目录`},{"search-buttons":e(()=>[t(y(E),null,{buttons:e(()=>[t(M,{onClick:c[2]||=e=>{f.value=``,p.value=`全部`}},{default:e(()=>[...c[18]||=[i(` 重置 `,-1)]]),_:1})]),default:e(()=>[t(y(O),null,{default:e(()=>[l(t(d,{modelValue:f.value,"onUpdate:modelValue":c[0]||=e=>f.value=e,"data-testid":y(k).search,placeholder:`搜索名称、用途、源码路径`,"allow-clear":``},null,8,[`modelValue`,`data-testid`]),[[$]])]),_:1}),t(y(O),null,{default:e(()=>[t(b,{modelValue:p.value,"onUpdate:modelValue":c[1]||=e=>p.value=e,options:g,"data-testid":y(k).category,placeholder:`组件分类`},null,8,[`modelValue`,`data-testid`])]),_:1})]),_:1})]),default:e(()=>[t(y(S),{columns:de,data:A.value,"show-pagination":!1,"row-key":`name`},{name:e(({record:e})=>[u(`strong`,null,_(e.name),1)]),category:e(({record:e})=>[t(y(w),{label:e.category,type:`info`,"enable-min-width":!1},null,8,[`label`])]),actions:e(({record:n})=>[t(M,{type:`text`,"data-testid":`${y(k).details}-${n.name}`,onClick:e=>I.value=n},{default:e(()=>[...c[19]||=[i(` 用法与源码 `,-1)]]),_:1},8,[`data-testid`,`onClick`])]),_:1},8,[`data`])]),_:1})]),_:1}),t(K,{key:`preview`,title:`交互示例`},{default:e(()=>[u(`div`,ie,[t(y(T),{title:`按钮与状态`},{default:e(()=>[t(pe,{wrap:``},{default:e(()=>[t(M,{type:`primary`,"data-testid":y(k).preview,onClick:c[3]||=e=>L.value=!0},{default:e(()=>[...c[20]||=[i(` 打开表单抽屉 `,-1)]]),_:1},8,[`data-testid`]),t(M,{onClick:fe},{default:e(()=>[...c[21]||=[i(` 确认弹框 `,-1)]]),_:1}),t(M,{disabled:``},{default:e(()=>[...c[22]||=[i(` 不可操作 `,-1)]]),_:1}),t(M,{loading:``},{default:e(()=>[...c[23]||=[i(` 处理中 `,-1)]]),_:1})]),_:1}),u(`div`,ae,[t(y(w),{label:`启用`,type:`success`}),t(y(w),{label:`待处理`,type:`warning`}),t(y(w),{label:`异常`,type:`danger`}),t(y(w),{label:`停用`,type:`info`})]),c[24]||=u(`p`,{class:`mt-5 text-xs text-[var(--color-text-3)]`},` 按钮使用 Arco，业务状态统一使用 CustomTag。 `,-1)]),_:1}),t(y(T),{title:`表单与选择`},{default:e(()=>[t(J,{model:{sampleName:R.value,sampleEnabled:z.value},layout:`vertical`},{default:e(()=>[t(q,{label:`文本输入`},{default:e(()=>[l(t(d,{modelValue:R.value,"onUpdate:modelValue":c[4]||=e=>R.value=e,"data-testid":y(k).input,placeholder:`输入时保留空格，失焦去除首尾空格`},null,8,[`modelValue`,`data-testid`]),[[$]])]),_:1}),t(q,{label:`有效期`},{default:e(()=>[t(y(D),{"start-date":B.value,"onUpdate:startDate":c[5]||=e=>B.value=e,"end-date":V.value,"onUpdate:endDate":c[6]||=e=>V.value=e,"long-term":H.value,"onUpdate:longTerm":c[7]||=e=>H.value=e},null,8,[`start-date`,`end-date`,`long-term`])]),_:1})]),_:1},8,[`model`])]),_:1}),t(y(T),{title:`状态筛选与步骤`},{default:e(()=>[t(y(x),{items:G,"active-key":U.value,onSelect:c[8]||=e=>U.value=e.key},null,8,[`active-key`]),t(y(C),{steps:le,"active-key":W.value},null,8,[`active-key`]),t(M,{class:`mt-5`,onClick:c[9]||=e=>W.value=W.value===`done`?`start`:`done`},{default:e(()=>[...c[25]||=[i(` 切换进度 `,-1)]]),_:1})]),_:1}),t(y(T),{title:`反馈与空数据`},{default:e(()=>[t(me,{type:`info`},{default:e(()=>[...c[26]||=[i(` 组件交互样例，不生成业务单据。 `,-1)]]),_:1}),t(he,{class:`mt-5`,description:`暂无记录，请调整筛选条件`})]),_:1})])]),_:1}),t(K,{key:`sources`,title:`源码盘点`},{default:e(()=>[t(y(T),{title:`业务页面与内部实现`},{default:e(()=>[c[27]||=u(`p`,null,`下列文件已扫描，但未提升为公共组件；页面内业务规则保持原归属。`,-1),t(ge,{data:y(j).remaining,columns:ue,pagination:!1,"row-key":`path`},null,8,[`data`])]),_:1})]),_:1}),t(K,{key:`rules`,title:`开发约定`},{default:e(()=>[t(y(T),{title:`组件复用顺序`},{default:e(()=>[t(X,{direction:`vertical`,current:1},{default:e(()=>[t(Y,{title:`先查本地组件目录`,description:`业务页面从 @nx/ui 引入项目组件；底层包保持原分层，禁止反向依赖 @nx/ui。`}),t(Y,{title:`基础控件使用现有 Arco`,description:`按钮、输入、选择、日期、弹框等沿用 a-*，不重复封装无差异组件。`}),t(Y,{title:`确实缺少时再查 GitHub`,description:`核对许可证、维护状态、Vue 3 / TypeScript 兼容、体积与暗色支持；接入本地组件库后供业务复用。`}),t(Y,{title:`组件与目录一起维护`,description:`登记用途和边界、补交互验证，运行 pnpm ui:inventory 更新源码清单。`})]),_:1}),t(_e),c[28]||=u(`p`,null,`样式沿用 Arco 主题变量、Tailwind 和现有 GlobalSiteConfig；表格用 NormalTable，页面用 ContentContainer，筛选用 SearchContainer + SearchCol。`,-1),c[29]||=u(`p`,null,`上传、实名、登录和租户组件依赖接口或宿主上下文。会员组件保持业务语义，不直接改作通用主体管理。`,-1),c[30]||=u(`p`,null,`源码中的旧 SvgIcon.vue / 404.vue 已有统一出口，后续不再直接引用旧文件。未导出的布局内部组件保持私有。`,-1)]),_:1})]),_:1})]),_:1}),t(Q,{visible:!!I.value,title:`组件用法`,width:560,footer:!1,onCancel:c[10]||=e=>I.value=null},{default:e(()=>[I.value?(n(),v(s,{key:0},[u(`h2`,null,_(I.value.name),1),u(`p`,null,_(I.value.purpose),1),t(ye,{column:1,bordered:``},{default:e(()=>[t(Z,{label:`分类`},{default:e(()=>[i(_(I.value.category),1)]),_:1}),t(Z,{label:`参数与边界`},{default:e(()=>[i(_(I.value.contract),1)]),_:1})]),_:1}),c[31]||=u(`h3`,null,`统一引用`,-1),u(`pre`,oe,`import { `+_(I.value.name)+` } from '@nx/ui';`,1),c[32]||=u(`h3`,null,`源码参数声明`,-1),u(`pre`,se,_(I.value.declarations||`此组件通过插槽或宿主上下文使用；详见实现。`),1),c[33]||=u(`h3`,null,`实现位置`,-1),u(`code`,ce,_(I.value.path),1),c[34]||=u(`h3`,null,`现有使用位置`,-1),u(`ul`,P,[(n(!0),v(s,null,a(I.value.examples,e=>(n(),v(`li`,{key:e,class:`break-all`},_(e),1))),128))]),I.value.examples.length?h(``,!0):(n(),v(`p`,F,` 暂未在页面模板中直接使用。 `))],64)):h(``,!0)]),_:1},8,[`visible`]),t(Q,{visible:L.value,"onUpdate:visible":c[13]||=e=>L.value=e,title:`表单示例`,width:440,onOk:c[14]||=e=>L.value=!1},{default:e(()=>[t(J,{model:{sampleName:R.value,sampleEnabled:z.value},layout:`vertical`},{default:e(()=>[t(q,{label:`名称`},{default:e(()=>[l(t(d,{modelValue:R.value,"onUpdate:modelValue":c[11]||=e=>R.value=e,placeholder:`请输入名称`},null,8,[`modelValue`]),[[$]])]),_:1}),t(q,{label:`状态`},{default:e(()=>[t(be,{modelValue:z.value,"onUpdate:modelValue":c[12]||=e=>z.value=e},null,8,[`modelValue`])]),_:1})]),_:1},8,[`model`])]),_:1},8,[`visible`])])}}});export{I as default};